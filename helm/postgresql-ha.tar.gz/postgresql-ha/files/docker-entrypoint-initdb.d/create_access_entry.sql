CREATE TABLE IF NOT EXISTS access_entry(
	   id SERIAL PRIMARY KEY,
	   ip CHAR(64),
	   xff CHAR(64),
	   user_agent CHAR(1024),
	   access_time TIMESTAMP,
	   path CHAR(1024)
);
