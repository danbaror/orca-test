You can copy here your custom `.sh` file(s) so they are executed every time Pgpool container is initialized

More info in the [bitnami-docker-pgpool](https://github.com/bitnami/bitnami-docker-postgresql-repmgr#initializing-with-custom-scripts) repository.
